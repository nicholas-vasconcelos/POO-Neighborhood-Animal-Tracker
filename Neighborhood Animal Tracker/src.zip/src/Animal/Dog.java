package Animal;

public class Dog extends Animal{

    public enum TailLength {
        SHORT("Short"),
        MEDIUM("Medium"),
        LONG("Long"),
        BOBBED("Bobbed"),
        CUT("Cut");

        private final String displayTailLength;

        TailLength(String displayTailLength) {
            this.displayTailLength = displayTailLength;
        }

        public String getDisplaySize(){
            return this.displayTailLength;
        }

        @Override
        public String toString() {
            return this.displayTailLength;
        }
    }

    private TailLength tailLength;
    private boolean chasesCars;
    private int barkLoudness;
    private boolean likesBeingPet;
    private boolean isVaccinated;
    private boolean isCastrated;

    public Dog(String id, String nickName, Color color, Size size, String species, TailLength tailLength,
               boolean chasesCars, int barkLoudness, boolean likesBeingPet, boolean isVaccinated, boolean isCastrated) {
        super(id, nickName, color, size, species);
        this.tailLength = tailLength;
        this.chasesCars = chasesCars;
        this.barkLoudness = barkLoudness;
        this.likesBeingPet = likesBeingPet;
        this.isVaccinated = isVaccinated;
        this.isCastrated = isCastrated;
    }

    public TailLength getTailLength() {
        return tailLength;
    }

    public void setTailLength(TailLength tailLength) {
        this.tailLength = tailLength;
    }

    public boolean isChasesCars() {
        return chasesCars;
    }

    public void setChasesCars(boolean chasesCars) {
        this.chasesCars = chasesCars;
    }

    public int getBarkLoudness() {
        return barkLoudness;
    }

    public void setBarkLoudness(int barkLoudness) {
        this.barkLoudness = barkLoudness;
    }

    public boolean isLikesBeingPet() {
        return likesBeingPet;
    }

    public void setLikesBeingPet(boolean likesBeingPet) {
        this.likesBeingPet = likesBeingPet;
    }

    public boolean isVaccinated() {
        return isVaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        isVaccinated = vaccinated;
    }

    public boolean isCastrated() {
        return isCastrated;
    }

    public void setCastrated(boolean castrated) {
        isCastrated = castrated;
    }
}
