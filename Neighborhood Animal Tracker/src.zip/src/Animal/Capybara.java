package Animal;

public class Capybara extends Animal{
    private int socialGroupSize;
    private boolean eatsGrass;
    private boolean walksOnStreet;

    public Capybara(String id, String nickName, Size size, int socialGroupSize, boolean eatsGrass, boolean walksOnStreet) {
        super(id, nickName, Color.BROWN, size, "Capybara");
        this.socialGroupSize = socialGroupSize;
        this.eatsGrass = eatsGrass;
        this.walksOnStreet = walksOnStreet;
    }

    public Capybara(String id, String nickName, Color color, Size size, String species,
                    int socialGroupSize, boolean eatsGrass) {
        super(id, nickName, Color.BROWN, size, "Capybara");
        this.socialGroupSize = socialGroupSize;
        this.eatsGrass = eatsGrass;
    }

    public int getSocialGroupSize() {
        return socialGroupSize;
    }

    public void setSocialGroupSize(int socialGroupSize) {
        this.socialGroupSize = socialGroupSize;
    }

    public boolean isEatsGrass() {
        return eatsGrass;
    }

    public void setEatsGrass(boolean eatsGrass) {
        this.eatsGrass = eatsGrass;
    }

    public boolean isWalksOnStreet() {
        return walksOnStreet;
    }

    public void setWalksOnStreet(boolean walksOnStreet) {
        this.walksOnStreet = walksOnStreet;
    }
}
