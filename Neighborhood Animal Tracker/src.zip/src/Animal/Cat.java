package Animal;

public class Cat extends Animal{

    private int purringVolume; // 0 to 10 need to force a way or suggest during report creation
    private boolean scratchesPeople;
    private boolean likesBeingPet;
    private boolean isVaccinated;
    private boolean isCastrated;

    public Cat(String id, String nickName, Color color, Size size, String species, int purringVolume,
               boolean scratchesPeople, boolean likesBeingPet, boolean isVaccinated, boolean isCastrated) {
        super(id, nickName, color, size, species);
        this.purringVolume = purringVolume;
        this.scratchesPeople = scratchesPeople;
        this.likesBeingPet = likesBeingPet;
        this.isVaccinated = isVaccinated;
        this.isCastrated = isCastrated;
    }

    public int getPurringVolume() {
        return purringVolume;
    }

    public void setPurringVolume(int purringVolume) {
        this.purringVolume = purringVolume;
    }

    public boolean isScratchesPeople() {
        return scratchesPeople;
    }

    public void setScratchesPeople(boolean scratchesPeople) {
        this.scratchesPeople = scratchesPeople;
    }

    public boolean isLikesBeingPet() {
        return likesBeingPet;
    }

    public void setLikesBeingPet(boolean likesBeingPet) {
        this.likesBeingPet = likesBeingPet;
    }

    public boolean isVaccinated() {
        return isVaccinated;
    }

    public void setVaccinated(boolean vaccinated) {
        isVaccinated = vaccinated;
    }

    public boolean isCastrated() {
        return isCastrated;
    }

    public void setCastrated(boolean castrated) {
        isCastrated = castrated;
    }

}
