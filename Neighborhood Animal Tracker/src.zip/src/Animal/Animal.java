package Animal;

public class Animal {

    protected String id;
    protected String nickName;
    protected Color color;
    protected Size size;
    protected String species;

    public Animal(String id, String nickName, Color color, Size size, String species) {
        this.id = id;
        this.nickName = nickName;
        this.color = color;
        this.size = size;
        this.species = species;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public Size getSize() {
        return size;
    }

    public void setSize(Size size) {
        this.size = size;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
}
