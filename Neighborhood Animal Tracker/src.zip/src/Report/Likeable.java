package Report;

public interface Likeable {
    
}
